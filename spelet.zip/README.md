# GeoClick Duel

En enkel 1‑mot‑1 onlinekart-quiz:

- Skapa konto med valfritt användarnamn/lösenord
- Logga in och gå till lobby
- Starta slumpmatch mot annan spelare
- Klicka på världskartan så nära staden som möjligt
- Poäng baseras på avstånd + tid (lägre är bättre)

## Utveckling lokalt

```bash
# Installera beroenden
npm run install-all

# I en terminal: starta server
npm run dev-server

# I en annan terminal: starta klient
npm run dev-client
